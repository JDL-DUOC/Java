package cl.delgadillo;

import cl.delgadillo.DAO.DaoConnection;
import cl.delgadillo.DAO.ProductoDAO;
import cl.delgadillo.GUI.FrMenu;
import cl.delgadillo.Model.Producto;

public class ZZRestaurante {

    public static void main(String[] args) {

// Se configura el  Look and Feel para asegurar que la interfaz tenga el aspecto correcto y no CAMBIE DE COLOR
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
// LLAMADA A CONECCION A BASE DE DATOS 
        DaoConnection daoConnection = DaoConnection.getInstancia(); //llamo a la conexion a mi base

// LLAMADA DE PANTALLA MENU PRINCIPAL
        FrMenu menu = new FrMenu();
        menu.setVisible(true);
        
      // LLAMADA A AGREGAR PRODUCTO
        AgregarProducto();
           
    }

public static void AgregarProducto() {
        // Crear un objeto Producto
        Producto producto1 = new Producto(1, "Hamburguesa Extra Grande", 8900, "Cocina");
        Producto producto2 = new Producto(2, "Hamburguesa Grande", 7500,"Cocina"); 
        Producto producto3 = new Producto(3, "Hamburguesa Mediana", 6500,"Cocina"); 
        Producto producto4 = new Producto(4, "Hamburguesa Pequeña", 5000,"Cocina");
        Producto producto5 = new Producto(5, "Cerveza 500cc", 5000,"Bar");
        Producto producto6 = new Producto(6, "Coca cola 550cc", 3000,"Bar");
        Producto producto7 = new Producto(7, "Agua Mineral 500cc", 1800,"Bar");
        //ProductoDAO.insertar(producto1);
        //ProductoDAO.insertar(producto2);
        //ProductoDAO.insertar(producto3);
        //ProductoDAO.insertar(producto4);
        //ProductoDAO.insertar(producto5);
        //ProductoDAO.insertar(producto6);
        //ProductoDAO.insertar(producto7);

        System.out.println("Productos agregados: ");
    }


}


  //
//