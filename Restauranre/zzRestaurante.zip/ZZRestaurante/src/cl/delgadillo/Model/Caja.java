/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.Model;

/**
 *
 * @author JDL
 */
public class Caja {
    private int mesa;
    private String estado;
    private int total;


// CONSTRUCTORES

    public Caja(int mesa, String estado, int total) {
        this.mesa = mesa;
        this.estado = estado;
        this.total = total;
    }
    
// GET Y SET

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    
     
}




