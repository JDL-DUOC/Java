
package cl.delgadillo.Model;

import java.util.Date;

/**
 *
 * @author JDL
 */
public class Pedido {
    private int idPedido;
    private Date fecha;
    private int mesa;
    private String estado;
    private int total;
    
//Constructores
   //todos
    public Pedido(int idPedido, Date fecha, int mesa, String estado, int total) {
        this.idPedido = idPedido;
        this.fecha = fecha;
        this.mesa = mesa;
        this.estado = estado;
        this.total = total;
    }

  // Individual
    
    
    
//Get y Set

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getMesa() {
        return mesa;
    }

    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

//toString    

    @Override
    public String toString() {
        return "Pedido{" + "idPedido=" + idPedido + ", fecha=" + fecha + ", mesa=" + mesa + ", estado=" + estado + ", total=" + total + '}';
    }
    
    
    
    
}

