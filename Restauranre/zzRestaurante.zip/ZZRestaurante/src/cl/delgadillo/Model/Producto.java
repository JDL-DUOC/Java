
package cl.delgadillo.Model;

import cl.delgadillo.DAO.ProductoDAO;

/**
 *
 * @author JDL
 */
public class Producto {
    private int idProducto;
    private String nombreProducto;
    private int precio;
    private String categoria;
    
// Constructores

    public Producto(int idProducto, String nombreProducto, int precio, String categoria) {
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.precio = precio;
        this.categoria = categoria;
    }
// Get y Set

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
// ToString

    @Override
    public String toString() {
        return "Producto{" + "idProducto=" + idProducto + ", nombreProducto=" + nombreProducto + ", precio=" + precio + ", categoria=" + categoria + '}';
    }
    
   public Producto obtenerProducto() {
    ProductoDAO productoDAO = new ProductoDAO();
    return productoDAO.obtenerProductoPorId(this.idProducto);
} 
    
}
//
