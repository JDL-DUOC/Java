package cl.delgadillo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoConnection {

    private static DaoConnection bd;
    private static Connection conexion;

    // Constructor privado para la conexion inicial a la base de datos
    private DaoConnection() {
        try {
            String stConnect = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=207.231.108.32)(PORT=8521)))(CONNECT_DATA=(SERVICE_NAME=FREEPDB1)))";
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conexion = DriverManager.getConnection(stConnect, "apex_us_S3_13288842", "macarena");
            // conexion = DriverManager.getConnection(stConnect, "apex_us_S3_13288842", "apex_cl_S3_13288842");
            
            System.out.println("Conexion exitosa a la base de datos");
        } catch (Exception ex) {
            System.out.println("Error al conectar a la base de datos: " + ex.getMessage());
            Logger.getLogger(DaoConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Metodo para obtener una instancia unica de la conexion, verificando que este abierta
    public static DaoConnection getInstancia() {
        try {
            if (bd == null || conexion == null || conexion.isClosed()) {
                bd = new DaoConnection();
            }
        } catch (SQLException ex) {
            System.out.println("Error al verificar la conexion: " + ex.getMessage());
            Logger.getLogger(DaoConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return bd;
    }

    // Metodo para ejecutar una sentencia SQL, asegurando que se cierre el Statement despues de cada ejecucion
    public void ejecutaSQL(String stSQL) {
        Statement stmt = null;
        try {
            System.out.println("Ejecutando SQL: " + stSQL);
            stmt = conexion.createStatement();
            stmt.executeUpdate(stSQL);
        } catch (SQLException ex) {
            System.out.println("Error al ejecutar SQL: " + ex.getMessage());
            Logger.getLogger(DaoConnection.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            // Cerramos el Statement despues de la ejecucion
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar el Statement: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }

    // Metodo para obtener la conexion actual
    public Connection getConnection() {
        return conexion;
    }
}