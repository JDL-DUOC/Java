/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.DAO;

import cl.delgadillo.Model.Comanda;

/**
 *
 * @author JDL
 */
public class ComandaDAO {
    
    
    // Metodo para insertar un producto en la base de datos (COMANDA)
    public static void insertarComanda(Comanda comanda) {
    String stSQL = String.format(
        "INSERT INTO comanda (MESA, NOMBRE_PRODUCTO,CATEGORIA, CANTIDAD,ESTADO,PRECIO) VALUES (%d,'%s','%s',%d,'%s',%d  )",
        comanda.getMesa(), comanda.getNombreProducto(), comanda.getCategoria(), comanda.getCantidad(),comanda.getEstado(),comanda.getPrecio());
    DaoConnection.getInstancia().ejecutaSQL(stSQL);
} 
    
    
    
}
