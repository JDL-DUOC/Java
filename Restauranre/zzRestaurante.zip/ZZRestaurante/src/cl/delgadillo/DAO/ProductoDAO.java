package cl.delgadillo.DAO;

import cl.delgadillo.Model.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

 // METODO para insertar un producto en la base de datos (PRODUCTO)
    public static void insertar(Producto producto) {
    String stSQL = String.format(
        "INSERT INTO producto (ID_PRODUCTO, NOMBRE_PRODUCTO,PRECIO, CATEGORIA) VALUES (%d,'%s',%d,'%s')",
        producto.getIdProducto(), producto.getNombreProducto(), producto.getPrecio(), producto.getCategoria());
    DaoConnection.getInstancia().ejecutaSQL(stSQL);
} 
    
    
// METODO para obtener un producto por su ID
public Producto obtenerProductoPorId(int idProducto) {
    String sql = "SELECT * FROM producto WHERE ID_PRODUCTO = ?";
    Producto producto = null;

    try (Connection conexion = DaoConnection.getInstancia().getConnection();
         PreparedStatement statement = conexion.prepareStatement(sql)) {

        statement.setInt(1, idProducto);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String nombre = resultSet.getString("NOMBRE_PRODUCTO");
            int precio = resultSet.getInt("PRECIO");
            String categoria = resultSet.getString("CATEGORIA");
            producto = new Producto(idProducto, nombre, precio, categoria);
        }

    } catch (SQLException e) {
        System.out.println("Error al obtener el producto: " + e.getMessage());
    }

    return producto;
}
    
// Metodo para obtener todos los productos
public List<Producto> obtenerTodosLosProductos() {
    List<Producto> productos = new ArrayList<>();
    String sql = "SELECT * FROM producto";

    try (Connection conexion = DaoConnection.getInstancia().getConnection();
         PreparedStatement statement = conexion.prepareStatement(sql);
         ResultSet resultSet = statement.executeQuery()) {

        while (resultSet.next()) {
            int idProducto = resultSet.getInt("ID_PRODUCTO");
            String nombre = resultSet.getString("NOMBRE_PRODUCTO");
            int precio = resultSet.getInt("PRECIO");
            String categoria = resultSet.getString("CATEGORIA");

            Producto producto = new Producto(idProducto, nombre, precio, categoria);
            productos.add(producto);
        }

    } catch (SQLException e) {
        System.out.println("Error al obtener la lista de productos: " + e.getMessage());
    }

    return productos;
}
    
// METODO para verificar si un producto ya existe en la base de datos por su ID
public static boolean existeProducto(int idProducto) {
    String sql = "SELECT 1 FROM producto WHERE ID_PRODUCTO = ?"; // CONSULTA PARA VERIFICAR QUE EL PRODUCTO EXISTE
    try (Connection conexion = DaoConnection.getInstancia().getConnection();
         PreparedStatement statement = conexion.prepareStatement(sql)) {

        statement.setInt(1, idProducto); // Asignar el ID del producto
        ResultSet resultSet = statement.executeQuery();
        return resultSet.next(); //  SI HAY UN RESULTADO, QUIERE DECIR QUE EL PRODUCTO EXISTE

    } catch (SQLException e) {
        System.out.println("Error al verificar si el producto existe: " + e.getMessage());
        return false;
    }
}
   
}