/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.DAO;

import cl.delgadillo.Model.Caja;
import cl.delgadillo.Model.Comanda;

/**
 *
 * @author JDL
 */
public class CajaDAO {
    // Metodo para insertar un producto en la base de datos (CAJA)
    public static void insertarCaja(Caja caja) {
    String stSQL = String.format(
        "INSERT INTO caja (MESA, ESTADO,TOTAL) VALUES (%d,'%s',%d  )",
        caja.getMesa(), caja.getEstado(), caja.getTotal());
    DaoConnection.getInstancia().ejecutaSQL(stSQL);
} 
    
  
}
