/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.DAO;

import cl.delgadillo.MODEL.Usuario;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DUOC
 */
public class UsuarioDAO {
    private static final ArrayList<Usuario> listaUsuario = new ArrayList<>();
    
    // Metodo para agregarJD un cliente a la lista
    public static void agregarJD(Usuario usuario) {
        listaUsuario.add(usuario);
    }

    // Metodo para obtener todos los clientes de la lista
    public List<Usuario> obtenerUsuarioJD() {
        // Retorna la lista actual de clientes
        return new ArrayList<>(listaUsuario);
    }

public static Usuario buscarPorRutJD(int rut) {
    for (Usuario usuario : listaUsuario) { 
        if (usuario.getRut() == rut) {
            return usuario;
        }
    }
    return null; // Si no se encuentra el usuario
}

// Metodo para eliminar un cliente de la lista
public static void eliminarUsuarioJD(Usuario usuario) {
    listaUsuario.remove(usuario);
}




}
