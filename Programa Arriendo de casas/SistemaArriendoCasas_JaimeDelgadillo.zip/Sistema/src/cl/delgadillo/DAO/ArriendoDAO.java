/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.DAO;

import cl.delgadillo.MODEL.Arriendo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DUOC
 */
public class ArriendoDAO {
    private static final ArrayList<Arriendo> listaArriendo = new ArrayList<>();
    
    // Metodo para agregarJD un arriendo
    public static void agregarArriendoJD(Arriendo arriendo) {
        listaArriendo.add(arriendo);
    }

    // Metodo para obtener todos los arriendos de la lista
    public List<Arriendo> obtenerArriendoJD() {
        // Retorna la lista actual de arriendos
        return new ArrayList<>(listaArriendo);
    }

    
public static Arriendo buscarArriendoJD(String fechaArriendo) {
    for (Arriendo arriendo : listaArriendo) { 
        if (arriendo.getFechaArriendo().equals( fechaArriendo)) {
            return arriendo;
        }
    }
    return null; // Si no se encuentra el arriendo
}

// Metodo para eliminar arriendo
public static void eliminarArriendoJD(Arriendo arriendo) {
    listaArriendo.remove(arriendo);
}
    
}

