/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.DAO;

import cl.delgadillo.MODEL.Casa;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author DUOC
 */
public class CasaDAO {
        private static final ArrayList<Casa> listaCasa = new ArrayList<>();
    
    // Metodo para agregarJD una casa a la lista
    public static void agregarCasaJD(Casa casa) {
        listaCasa.add(casa);
    }

    // Metodo para obtener todos los clientes de la lista
    public List<Casa> obtenerCasaJD() {
        // Retorna la lista actual de clientes
        return new ArrayList<>(listaCasa);
    }

public static Casa buscarCasaJD(int idCasa) {
    for (Casa casa : listaCasa) { 
        if (casa.getIdCasa() == idCasa) {
            return casa;
        }
    }
    return null; // Si no se encuentra la casa
}

// Metodo para eliminar casa
public static void eliminarCasaJD(Casa casa) {
    listaCasa.remove(casa);
}
    
   
}
