
package cl.delgadillo.MODEL;



public class Cliente {
    private int rut;
    private String dv;
    private String nombre;
    private String aPaterno;
    private String aMaterno;
    private String nacionalidad;
   
 
// Constructores 

        public Cliente(int rut, String dv, String nombre, String aPaterno, String aMaterno, String nacionalidad) {
            this.rut = rut;
            this.dv = dv;
            this.nombre = nombre;
            this.aPaterno = aPaterno;
            this.aMaterno = aMaterno;
            this.nacionalidad = nacionalidad;
        }

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public String getDv() {
        return dv;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getaPaterno() {
        return aPaterno;
    }

    public void setaPaterno(String aPaterno) {
        this.aPaterno = aPaterno;
    }

    public String getaMaterno() {
        return aMaterno;
    }

    public void setaMaterno(String aMaterno) {
        this.aMaterno = aMaterno;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

  
    }





        
    

