/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.MODEL;

/**
 *
 * @author DUOC
 */
public class Arriendo {
    private String fechaArriendo;
    private String fechaFinArriendo;
    private String aplicaMulta;
    private int totalMulta;

    public Arriendo(String fechaArriendo, String fechaFinArriendo, String aplicaMulta, int totalMulta) {
        this.fechaArriendo = fechaArriendo;
        this.fechaFinArriendo = fechaFinArriendo;
        this.aplicaMulta = aplicaMulta;
        this.totalMulta = totalMulta;
    }

    public String getFechaArriendo() {
        return fechaArriendo;
    }

    public void setFechaArriendo(String fechaArriendo) {
        this.fechaArriendo = fechaArriendo;
    }

    public String getFechaFinArriendo() {
        return fechaFinArriendo;
    }

    public void setFechaFinArriendo(String fechaFinArriendo) {
        this.fechaFinArriendo = fechaFinArriendo;
    }

    public String getAplicaMulta() {
        return aplicaMulta;
    }

    public void setAplicaMulta(String aplicaMulta) {
        this.aplicaMulta = aplicaMulta;
    }

    public int getTotalMulta() {
        return totalMulta;
    }

    public void setTotalMulta(int totalMulta) {
        this.totalMulta = totalMulta;
    }
    
    
}
