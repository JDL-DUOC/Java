/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.delgadillo.MODEL;

/**
 *
 * @author DUOC
 */
public class Casa {
    private int idCasa;
    private String calle;
    private String calleNro;
    private int valorVenta;
    private int valorCasa;
    private int mt2;

    public Casa(int idCasa, String calle, String calleNro, int valorVenta, int valorCasa, int mt2) {
        this.idCasa = idCasa;
        this.calle = calle;
        this.calleNro = calleNro;
        this.valorVenta = valorVenta;
        this.valorCasa = valorCasa;
        this.mt2 = mt2;
    }

    public int getIdCasa() {
        return idCasa;
    }

    public void setIdCasa(int idCasa) {
        this.idCasa = idCasa;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getCalleNro() {
        return calleNro;
    }

    public void setCalleNro(String calleNro) {
        this.calleNro = calleNro;
    }

    public int getValorVenta() {
        return valorVenta;
    }

    public void setValorVenta(int valorVenta) {
        this.valorVenta = valorVenta;
    }

    public int getValorCasa() {
        return valorCasa;
    }

    public void setValorCasa(int valorCasa) {
        this.valorCasa = valorCasa;
    }

    public int getMt2() {
        return mt2;
    }

    public void setMt2(int mt2) {
        this.mt2 = mt2;
    }
 
    

}
