
package cl.delgadillo.GUI;

import cl.delgadillo.DAO.CasaDAO;
import cl.delgadillo.MODEL.Casa;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrListadoCasa extends javax.swing.JFrame {

    /**
     * Creates new form FrListadoCasa
     */
    public FrListadoCasa() {
        initComponents();
        cargarCasasJD();   //LLAMADO AL METODO cargarCasasJD       ////
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaCasaJD = new javax.swing.JTable();
        BtRegresar = new javax.swing.JButton();
        BtEliminar = new javax.swing.JButton();
        BtEditar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("LISTADO CASAS");

        TablaCasaJD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID CASA", "CALLE", "NUMERO CALLE", "VALOR VENTA", "VALOR CASA", "MT2"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TablaCasaJD);

        BtRegresar.setText("Regresar");
        BtRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtRegresarActionPerformed(evt);
            }
        });

        BtEliminar.setText("Eliminar");
        BtEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtEliminarActionPerformed(evt);
            }
        });

        BtEditar.setText("Editar");
        BtEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtEditarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 374, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(337, 337, 337))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(BtEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(BtEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BtRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(BtRegresar, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(BtEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(BtEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(84, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//Metodo para hacer visible o ocultar boton [EDITAR]
    public void setBtEditarVisible(boolean visible) {   
    BtEditar.setVisible(visible);                 
}

//Metodo para hacer visible o ocultar boton [ELIMINAR]
    public void setBtEliminarVisible(boolean visible) {   
    BtEliminar.setVisible(visible);                 
}
   
    
    
    ////     METODO PARA REALIZAR LISTADO       ////
    private void cargarCasasJD() {
        // Obtenemos la lista de casas desde el DAO
        CasaDAO casaDAO = new CasaDAO();
        List<Casa> listaCasas = casaDAO.obtenerCasaJD();

        // Obtenemos el modelo de la tabla
        DefaultTableModel modelo = (DefaultTableModel) TablaCasaJD.getModel();
        
        // Limpiamos las filas existentes antes de agregarJD nuevas
        modelo.setRowCount(0);

        // Recorremos la lista de casas y agregamos cada uno a la tabla
        for (Casa casa : listaCasas) {
            modelo.addRow(new Object[] {
                casa.getIdCasa(),
                casa.getCalle(),
                casa.getCalleNro(),
                casa.getValorVenta(),
                casa.getValorCasa(),
                casa.getMt2()
               
            });
        }
    }
         
    private void BtRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtRegresarActionPerformed
        
    FrMenuJD menu = new FrMenuJD();
    menu.setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_BtRegresarActionPerformed

    private void BtEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtEliminarActionPerformed
                                                 
    // Obtener la fila seleccionada en la tabla
    int filaSeleccionada = TablaCasaJD.getSelectedRow();
    
    // Verificar si se ha seleccionado una fila
    if (filaSeleccionada != -1) {
        // Obtener el RUT del casa de la fila seleccionada
        int idCasa = (int) TablaCasaJD.getValueAt(filaSeleccionada, 0);

        // Eliminar el casa de la lista en CasaDAO
        Casa casaEliminar = CasaDAO.buscarCasaJD(idCasa);
        if (casaEliminar != null) {
            // Eliminar el casa de la lista del DAO
            CasaDAO.eliminarCasaJD(casaEliminar);
            
            // Eliminar la fila de la tabla
            DefaultTableModel modelo = (DefaultTableModel) TablaCasaJD.getModel();
            modelo.removeRow(filaSeleccionada);
        }
    } else {
        // Si no hay ninguna fila seleccionada, puedes mostrar un mensaje de advertencia
        JOptionPane.showMessageDialog(this, "Por favor, selecciona un casa para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
        
         
    }//GEN-LAST:event_BtEliminarActionPerformed

    private void BtEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtEditarActionPerformed
                                                        
    int filaSeleccionada = TablaCasaJD.getSelectedRow();
    if (filaSeleccionada != -1) {
        // Recuperar el casa seleccionado
        Casa casaEditar = CasaDAO.buscarCasaJD((int) TablaCasaJD.getValueAt(filaSeleccionada, 0));

        // Editar celdas directamente en la tabla
        // Verificar si los datos cambiaron en los campos editables
        String nuevocalle = (String) TablaCasaJD.getValueAt(filaSeleccionada, 1);
        if (!casaEditar.getCalle().equals(nuevocalle)) {
            casaEditar.setCalle(nuevocalle);
        }

        String nuevocalleNro = (String) TablaCasaJD.getValueAt(filaSeleccionada, 2);
        if (!casaEditar.getCalleNro().equals(nuevocalleNro)) {
            casaEditar.setCalleNro(nuevocalleNro);
        }

        int nuevovalorCasa = (int) TablaCasaJD.getValueAt(filaSeleccionada, 3);
        if (casaEditar.getValorCasa() != nuevovalorCasa) {
            casaEditar.setValorCasa(nuevovalorCasa);
        }
        int nuevovalorVenta = (int) TablaCasaJD.getValueAt(filaSeleccionada, 3);
        if (casaEditar.getValorCasa() != nuevovalorVenta) {
            casaEditar.setValorCasa(nuevovalorVenta);
        }
        int nuevomt2 = (int) TablaCasaJD.getValueAt(filaSeleccionada, 3);
        if (casaEditar.getValorCasa() != nuevomt2) {
            casaEditar.setValorCasa(nuevomt2);
              
        }

      // Mostrar mensaje de éxito
        JOptionPane.showMessageDialog(null, "Lista editada OK,", "Exito", JOptionPane.INFORMATION_MESSAGE);  
                                                      
     
    }//GEN-LAST:event_BtEditarActionPerformed
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrListadoCasa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrListadoCasa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrListadoCasa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrListadoCasa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrListadoCasa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtEditar;
    private javax.swing.JButton BtEliminar;
    private javax.swing.JButton BtRegresar;
    private javax.swing.JTable TablaCasaJD;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
