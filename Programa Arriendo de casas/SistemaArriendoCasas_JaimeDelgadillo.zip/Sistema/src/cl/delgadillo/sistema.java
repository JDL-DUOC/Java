/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cl.delgadillo;

import cl.delgadillo.GUI.FrMenuJD;

/**
 *
 * @author DUOC
 */
public class sistema {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
         // Establece el Look and Feel Nimbus  (PARA QUE NO SE CAMBIE LA INTERFAZ VISUAL DE LAS PANTALLAS)
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            System.err.println("Error al configurar Look and Feel: " + ex.getMessage());
        }
   
     
       FrMenuJD menu = new FrMenuJD();
        menu.setVisible(true);
    }
    
}
