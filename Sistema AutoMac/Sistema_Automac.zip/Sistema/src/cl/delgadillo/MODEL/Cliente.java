
package cl.delgadillo.MODEL;


public class Cliente {
    private int rut;
    private String dv;
    private String nombre;
    private String aPaterno;
    private String aMaterno;
    private String telefono;
    private String correo;
 
// Constructores 

    public Cliente(int rut, String dv, String nombre, String aPaterno, String aMaterno, String telefono, String correo) {
        this.rut = rut;
        this.dv = dv;
        this.nombre = nombre;
        this.aPaterno = aPaterno;
        this.aMaterno = aMaterno;
        this.telefono = telefono;
        this.correo = correo;
    }

// Get y set

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public String getDv() {
        return dv;
    }

    public void setDv(String dv) {
        this.dv = dv;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getaPaterno() {
        return aPaterno;
    }

    public void setaPaterno(String aPaterno) {
        this.aPaterno = aPaterno;
    }

    public String getaMaterno() {
        return aMaterno;
    }

    public void setaMaterno(String aMaterno) {
        this.aMaterno = aMaterno;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    @Override
    public String toString() {
        return "Cliente{" + "rut=" + rut + ", dv=" + dv + ", nombre=" + nombre + ", aPaterno=" + aPaterno + ", aMaterno=" + aMaterno + ", telefono=" + telefono + ", correo=" + correo + '}';
    }
 
    public void imprimircliente() {
           System.out.println(this.toString());
    
    }

}
