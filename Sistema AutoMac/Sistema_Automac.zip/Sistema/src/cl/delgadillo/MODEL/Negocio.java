
package cl.delgadillo.MODEL;

import java.time.LocalDateTime;
import java.util.Date;


public class Negocio {
  
  private LocalDateTime fechaHora;
  private int rut;
  private String nombre;
  private String aPaterno;
  private String aMaterno;
  private String correo;
  private String patente;
  private String marca;
  private String modelo;
  private int precioVenta;

    public Negocio(LocalDateTime fechaHora, int rut, String nombre, String aPaterno, String aMaterno, String correo, String patente, String marca, String modelo, int precioVenta) {
        this.fechaHora = fechaHora;
        this.rut = rut;
        this.nombre = nombre;
        this.aPaterno = aPaterno;
        this.aMaterno = aMaterno;
        this.correo = correo;
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.precioVenta = precioVenta;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getaPaterno() {
        return aPaterno;
    }

    public void setaPaterno(String aPaterno) {
        this.aPaterno = aPaterno;
    }

    public String getaMaterno() {
        return aMaterno;
    }

    public void setaMaterno(String aMaterno) {
        this.aMaterno = aMaterno;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(int precioVenta) {
        this.precioVenta = precioVenta;
    }

    
}
