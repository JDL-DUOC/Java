
package cl.delgadillo.MODEL;


public class Vehiculo {
    private String patente;
    private String marca;
    private String modelo;
    private String maxVelocidad;
    private String ener;
    private String air;
    
    public Vehiculo(String patente, String marca, String modelo, String maxVelocidad, String ener,String air) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.maxVelocidad = maxVelocidad;
        this.ener = ener;
        this.air = air;
    }

    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMaxVelocidad() {
        return maxVelocidad;
    }

    public void setMaxVelocidad(String maxVelocidad) {
        this.maxVelocidad = maxVelocidad;
    }

  ////////////////////////////////////////////////////
    public String getEner() {
        return ener;
    }

    public void setEner(String ener) {
        this.ener = ener;
    }

    public String getAir() {
        return air;
    }

    public void setAir(String air) {
        this.air = air;
    }
 /////////////////////////////////////////////////// 

    @Override
    public String toString() {
        return "Vehiculo{" + "patente=" + patente + ", marca=" + marca + ", modelo=" + modelo + ", maxVelocidad=" + maxVelocidad + ", ener=" + ener + ", air=" + air + '}';
    }
    
    public void imprimirvehiculo() {
           System.out.println(this.toString());
    
    }

    
    
    
    
    
    
     
}




