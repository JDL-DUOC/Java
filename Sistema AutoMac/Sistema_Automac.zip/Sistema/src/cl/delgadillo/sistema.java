package cl.delgadillo;

import cl.delgadillo.DAO.ClienteDAO;
import cl.delgadillo.DAO.VehiculoDAO;
import cl.delgadillo.GUI.FrMenuJD;
import cl.delgadillo.MODEL.Cliente;
import cl.delgadillo.MODEL.Vehiculo;


public class sistema {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Establece el Look and Feel Nimbus  (PARA QUE NO SE CAMBIE LA INTERFAZ VISUAL DE LAS PANTALLAS)
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            System.err.println("Error al configurar Look and Feel: " + ex.getMessage());
        }
        
//CREACION DE OBJETOS
        //CLIENTE
        Cliente cliente1= new Cliente (1111,"1","Juan","perez","perez","+569565665","correo@correo.cl");
        
        
        //VEHICULO
        Vehiculo vehiculo1=new Vehiculo ("xxyz12","Toyota","Hilux","100.000","750","");
        Vehiculo vehiculo2=new Vehiculo ("ttxx23","Nissan","Versa","120.000","Convensional","si");
        
        
        // Agregar el cliente al ArrayList de ClienteDAO
        ClienteDAO.agregarJD(cliente1);
         
        // Agregar el vehiculo al ArrayList de VehiculoDAO
        VehiculoDAO.agregarVehiculoJD(vehiculo1);
        VehiculoDAO.agregarVehiculoJD(vehiculo2);
        
        
        
      // Muestro por CONSOLA LOS CLIENTES AGRGADOS DESDE MAIN                         
      ClienteDAO clienteDAO = new ClienteDAO();
      System.out.println("Clientes actuales en la lista:");
      for (Cliente cliente : clienteDAO.obtenerClientesJD()) {
      System.out.println(cliente.toString());
      }
        
        
      // Muestro por CONSOLA LOS CLIENTES AGRGADOS DESDE MAIN                         
      VehiculoDAO vehiculoDAO = new VehiculoDAO();
      System.out.println("Vehiculos actuales en la lista:");
      for (Vehiculo vehiculo : vehiculoDAO.obtenerVehiculosJD()) {
      System.out.println(vehiculo.toString());
      }  
        
        
        
        
        //LLAMAR DIRECTAMENTA A FrMenu
               
        FrMenuJD menu = new FrMenuJD();
        menu.setVisible(true);
        
        
    }
    
}
