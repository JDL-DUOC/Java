
package cl.delgadillo.GUI;

import cl.delgadillo.DAO.ClienteDAO;
import cl.delgadillo.MODEL.Cliente;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class FrListadoCliente extends javax.swing.JFrame {

    /**
     * Creates new form FrListadoCliente
     */
    public FrListadoCliente() {
        initComponents();
        TablaClienteJD.setAutoCreateRowSorter(true); // Activar el ordenamiento automatico
        cargarClientesJD();   //LLAMADO AL METODO cargarClientesJD       ////
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaClienteJD = new javax.swing.JTable();
        BtRegresar = new javax.swing.JButton();
        BtEliminar = new javax.swing.JButton();
        BtEditar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("LISTADO CLIENTES");

        TablaClienteJD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "RUT", "DV", "NOMBRE", "APELLIDO PATERNO", "APELLIDO MATERNO", "TELEFONO", "CORREO"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, true, true, true, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(TablaClienteJD);

        BtRegresar.setText("Regresar");
        BtRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtRegresarActionPerformed(evt);
            }
        });

        BtEliminar.setText("Eliminar");
        BtEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtEliminarActionPerformed(evt);
            }
        });

        BtEditar.setText("Editar");
        BtEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtEditarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 374, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(337, 337, 337))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(BtEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(BtEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BtRegresar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(BtRegresar, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(BtEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(BtEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(84, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//Metodo para hacer visible o ocultar boton [EDITAR]
    public void setBtEditarVisible(boolean visible) {   
    BtEditar.setVisible(visible);                 
}

//Metodo para hacer visible o ocultar boton [ELIMINAR]
    public void setBtEliminarVisible(boolean visible) {   
    BtEliminar.setVisible(visible);                 
}
    
            
    ////     METODO PARA REALIZAR LISTADO       ////
    private void cargarClientesJD() {
        // Obtenemos la lista de clientes desde el DAO
        ClienteDAO clienteDAO = new ClienteDAO();
        List<Cliente> listaClientes = clienteDAO.obtenerClientesJD();

        // Obtenemos el modelo de la tabla
        DefaultTableModel modelo = (DefaultTableModel) TablaClienteJD.getModel();
        
        // Limpiamos las filas existentes antes de agregarJD nuevas
        modelo.setRowCount(0);

        // Recorremos la lista de clientes y agregamos cada uno a la tabla
        for (Cliente cliente : listaClientes) {
            modelo.addRow(new Object[] {
                cliente.getRut(),
                cliente.getDv(),
                cliente.getNombre(),
                cliente.getaPaterno(),
                cliente.getaMaterno(),
                cliente.getTelefono(),
                cliente.getCorreo()
            });
        }
    }
         
    private void BtRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtRegresarActionPerformed
        
        FrMenuJD menu = new FrMenuJD();
    menu.setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_BtRegresarActionPerformed

    private void BtEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtEliminarActionPerformed
                                                 
    // Obtener la fila seleccionada en la tabla
    int filaSeleccionada = TablaClienteJD.getSelectedRow();
    
    // Verificar si se ha seleccionado una fila
    if (filaSeleccionada != -1) {
        // Obtener el RUT del cliente de la fila seleccionada
        int rutCliente = (int) TablaClienteJD.getValueAt(filaSeleccionada, 0);

        // Eliminar el cliente de la lista en ClienteDAO
        Cliente clienteAEliminar = ClienteDAO.buscarPorRutJD(rutCliente);
        if (clienteAEliminar != null) {
            // Eliminar el cliente de la lista del DAO
            ClienteDAO.eliminarClienteJD(clienteAEliminar);
            
            // Eliminar la fila de la tabla
            DefaultTableModel modelo = (DefaultTableModel) TablaClienteJD.getModel();
            modelo.removeRow(filaSeleccionada);
        
           // SE MUESTRA MENSAJE BORRADO CON EXITO
              JOptionPane.showMessageDialog(this, "Cliente eliminado con exito.", "Exito", JOptionPane.INFORMATION_MESSAGE);
        
        }
    } else {
        // Si no hay ninguna fila seleccionada, puedes mostrar un mensaje de advertencia
        JOptionPane.showMessageDialog(this, "Por favor, selecciona un cliente para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
        
                
    }//GEN-LAST:event_BtEliminarActionPerformed

    private void BtEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtEditarActionPerformed
                                                        
    int filaSeleccionada = TablaClienteJD.getSelectedRow();
    //if (filaSeleccionada != -1) {
     
// SE VERIFICA SI NO SE SELECCIONO UNA FILA
    if (filaSeleccionada == -1) {
         JOptionPane.showMessageDialog(null, "Por favor, selecciona un cliente para editar", "Advertencia", JOptionPane.WARNING_MESSAGE);
        } else {        

// Recuperar el cliente seleccionado
        Cliente clienteAEditar = ClienteDAO.buscarPorRutJD((int) TablaClienteJD.getValueAt(filaSeleccionada, 0));

        // Editar celdas directamente en la tabla
        // Verificar si los datos cambiaron en los campos editables
        String nuevoNombre = (String) TablaClienteJD.getValueAt(filaSeleccionada, 2);
        if (!clienteAEditar.getNombre().equals(nuevoNombre)) {
            clienteAEditar.setNombre(nuevoNombre);
        }

        String nuevoaPaterno = (String) TablaClienteJD.getValueAt(filaSeleccionada, 3);
        if (!clienteAEditar.getaPaterno().equals(nuevoaPaterno)) {
            clienteAEditar.setaPaterno(nuevoaPaterno);
        }

        String nuevoaMaterno = (String) TablaClienteJD.getValueAt(filaSeleccionada, 4);
        if (!clienteAEditar.getaMaterno().equals(nuevoaMaterno)) {
            clienteAEditar.setaMaterno(nuevoaMaterno);
        }

        String nuevoTelefono = (String) TablaClienteJD.getValueAt(filaSeleccionada, 5);
        if (!clienteAEditar.getTelefono().equals(nuevoTelefono)) {
            clienteAEditar.setTelefono(nuevoTelefono);
        }

        String nuevoCorreo = (String) TablaClienteJD.getValueAt(filaSeleccionada, 6);
        if (!clienteAEditar.getCorreo().equals(nuevoCorreo)) {
            clienteAEditar.setCorreo(nuevoCorreo);
        }

      // Mostrar mensaje de éxito
        JOptionPane.showMessageDialog(null, "Cliente editado con exito", "Exito", JOptionPane.INFORMATION_MESSAGE);  
    }                                                   
     
    }//GEN-LAST:event_BtEditarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrListadoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrListadoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrListadoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrListadoCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrListadoCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtEditar;
    private javax.swing.JButton BtEliminar;
    private javax.swing.JButton BtRegresar;
    private javax.swing.JTable TablaClienteJD;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
