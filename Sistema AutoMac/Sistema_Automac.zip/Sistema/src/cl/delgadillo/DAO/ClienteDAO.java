package cl.delgadillo.DAO;

import cl.delgadillo.MODEL.Cliente;
import java.util.List;  
import java.util.ArrayList;

public class ClienteDAO {
    
    private static final ArrayList<Cliente> listaCliente = new ArrayList<>();
    
    // Metodo para agregarJD un cliente a la lista
    public static void agregarJD(Cliente cliente) {
        listaCliente.add(cliente);
    }

    // Metodo para obtener todos los clientes de la lista
    public List<Cliente> obtenerClientesJD() {
        // Retorna la lista actual de clientes
        return new ArrayList<>(listaCliente);
    }

       
    
    
    
public static Cliente buscarPorRutJD(int rut) {
    for (Cliente cliente : listaCliente) { 
        if (cliente.getRut() == rut) {
            return cliente;
        }
    }
    return null; // Si no se encuentra el cliente
}

// Metodo para eliminar un cliente de la lista
public static void eliminarClienteJD(Cliente cliente) {
    listaCliente.remove(cliente);
}


}

