package cl.delgadillo.DAO;

import cl.delgadillo.MODEL.Vehiculo;
import java.util.List;  
import java.util.ArrayList;

public class VehiculoDAO {
    
    private static final ArrayList<Vehiculo> listaVehiculo = new ArrayList<>();
    
    // Metodo para agregarJD un vehiculo a la lista
    public static void agregarVehiculoJD(Vehiculo vehiculo) {
        listaVehiculo.add(vehiculo);
    }

    // Metodo para obtener todos los vehiculos de la lista
    public List<Vehiculo> obtenerVehiculosJD() {
        // Retorna la lista actual de clientes
        return new ArrayList<>(listaVehiculo);
    }

public static Vehiculo buscarPorPatenteJD(String patente) {
    for (Vehiculo vehiculo : listaVehiculo) { 
        if ( vehiculo.getPatente().equals(patente)) {
            return vehiculo;
        }
    }
    return null; // Si no se encuentra el vehiculo
}

// Metodo para eliminar un vehiculo de la lista
public static void eliminarVehiculoJD(Vehiculo vehiculo) {
    listaVehiculo.remove(vehiculo);
}


}

