
package cl.delgadillo.DAO;

import cl.delgadillo.MODEL.Negocio;

import java.util.ArrayList;
import java.util.List;


public class NegocioDAO {
    
    private static final ArrayList<Negocio> listaNegocio = new ArrayList<>();
    
    // Metodo para agregarJD una venta a la lista
    public static void agregarNegocioJD(Negocio negocio) {
        listaNegocio.add(negocio);
    }

    // Metodo para obtener todos los vehiculos de la lista
    public List<Negocio> obtenerNegocioJD() {
        // Retorna la lista actual de clientes
        return new ArrayList<>(listaNegocio);
    }


// Metodo para eliminar una venta de la lista
public static void eliminarNegocioJD(Negocio negocio) {
    listaNegocio.remove(negocio);
}


// Metodo para verificar si una patente ya existe en la lista
    public static boolean patenteExistente(String patente) {
        for (Negocio negocio : listaNegocio) {
            if (negocio.getPatente().equals(patente)) {
                return true; // La patente ya existe
            }
        }
        return false; // La patente no existe
    }

}



